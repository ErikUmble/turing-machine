From command-line:
Run java -jar TuringMachine4.jar [input file] [-type=quad|quint]
From the command line, the user can select an input file, as well as the type of machine to open.
Also, you can run java -jar TuringMachine4.jar -h to get these usage instructions.

Otherwise, if you drag an input file onto the .jar or .bat file (on windows), the software will open with that TM file.

Compatible with Java version 1.6 and above.
